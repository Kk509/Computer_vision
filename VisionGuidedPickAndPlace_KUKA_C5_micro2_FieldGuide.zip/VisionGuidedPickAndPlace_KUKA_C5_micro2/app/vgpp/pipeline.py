from .vision.boxpick import parse_grasps, filter_grasps
from .geometry.transforms import make_transform, transform_pose

def process_boxpick_response(payload: dict, config: dict) -> list[dict]:
    bp = config["boxpick"]
    cal = config["calibration"]["camera_to_robot_base"]
    if not cal.get("confirmed"):
        raise RuntimeError("Camera-to-robot-base calibration is not confirmed.")
    candidates = parse_grasps(payload)
    candidates = filter_grasps(candidates, bp["minimum_grasp_quality"],
                               bp["minimum_ellipse_length_m"], bp["minimum_ellipse_width_m"])
    T = make_transform(cal["translation_m"], cal["quaternion_xyzw"])
    result = []
    for g in candidates:
        p, R = transform_pose(T, g.position_m, g.quaternion_xyzw)
        result.append({"item_id":g.item_id, "position_robot_base_m":p.tolist(),
                       "rotation_matrix_robot_base":R.tolist(), "quality":g.quality})
    return result
