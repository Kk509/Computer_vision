class IIQKAEthernetKRLAdapter:
    """Guarded integration boundary.

    This intentionally does not invent a wire protocol. An engineer must provide and
    verify the actual iiQKA.EthernetKRL configuration, KRL data contract, framing,
    handshake, timeout/fault semantics, and controller-side program.
    """
    def __init__(self, contract: dict):
        self.contract = contract

    def connect(self):
        raise NotImplementedError(
            "Physical iiQKA.OS2 adapter is locked: verify installed EthernetKRL package "
            "and supply the approved controller communication contract first."
        )

    def send_validated_target(self, target):
        raise RuntimeError("Physical robot motion is disabled pending commissioning.")

    def get_status(self):
        raise NotImplementedError("Controller status protocol has not been commissioned.")
