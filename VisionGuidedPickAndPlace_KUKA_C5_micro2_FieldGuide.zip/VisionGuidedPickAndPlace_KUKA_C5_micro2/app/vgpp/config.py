from pathlib import Path
import json
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
CONFIG_DIR = ROOT / "config"

def load_json(name: str) -> dict[str, Any]:
    path = CONFIG_DIR / name
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def load_all() -> dict[str, dict]:
    return {name[:-5]: load_json(name) for name in
            ["robot.json","camera.json","boxpick.json","gripper.json",
             "calibration.json","workspace.json","system.json"]}

def validate_config() -> list[str]:
    c = load_all()
    errors: list[str] = []
    r = c["robot"]
    if r["robot"]["model"] != "KR_6_R700_2_SEL":
        errors.append("Configured robot differs from the nameplate-confirmed KR_6_R700_2_SEL.")
    if r["robot"]["controller"] != "KR_C5_MICRO_2":
        errors.append("Configured controller differs from the nameplate-confirmed KR_C5_MICRO_2.")
    if r["communication"]["mode"] not in {"mock", "iiqka_ethernetkrl"}:
        errors.append("communication.mode must be 'mock' or 'iiqka_ethernetkrl'.")
    if not c["boxpick"]["min_dimensions_m"] or not c["boxpick"]["max_dimensions_m"]:
        errors.append("BoxPick dimension limits are missing.")
    if c["boxpick"]["suction_surface_length_m"] <= 0 or c["boxpick"]["suction_surface_width_m"] <= 0:
        errors.append("BoxPick suction surface dimensions must be positive.")
    tcp = c["gripper"]["tcp"]
    if not tcp.get("confirmed"):
        errors.append("Suction TCP has not been measured/confirmed.")
    if not c["gripper"]["suction_surface"].get("confirmed"):
        errors.append("Suction surface dimensions have not been measured/confirmed.")
    if not c["calibration"]["camera_to_robot_base"].get("confirmed"):
        errors.append("Camera-to-robot-base calibration is not confirmed.")
    if not c["workspace"]["pick_region"].get("confirmed") or not c["workspace"]["place_region"].get("confirmed"):
        errors.append("Pick/place workspace regions are not confirmed.")
    if r["motion"]["robot_motion_enabled"] or c["system"]["robot_motion_enabled"]:
        if not (r["motion"]["simulation_only"] is False and r["communication"]["mode"] == "iiqka_ethernetkrl"):
            errors.append("Motion enable requires simulation_only=false and the physical adapter mode.")
        errors.append("Physical motion remains locked pending engineer commissioning approval.")
    return errors
