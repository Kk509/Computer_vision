@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Project is not installed. Run WINDOWS_INSTALL.bat first.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
vgpp desktop
if errorlevel 1 (
  echo App failed to launch. Check installation and START_HERE.md.
  pause
)
