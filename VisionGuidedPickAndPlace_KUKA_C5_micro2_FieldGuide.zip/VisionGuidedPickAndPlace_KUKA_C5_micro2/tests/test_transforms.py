import numpy as np
from vgpp.geometry.transforms import make_transform, transform_pose

def test_identity_transform():
    T = make_transform([0,0,0], [0,0,0,1])
    p, R = transform_pose(T, [1,2,3], [0,0,0,1])
    assert np.allclose(p, [1,2,3])
    assert np.allclose(R, np.eye(3))

def test_translation():
    T = make_transform([1,0,0], [0,0,0,1])
    p, _ = transform_pose(T, [2,3,4], [0,0,0,1])
    assert np.allclose(p, [3,3,4])
