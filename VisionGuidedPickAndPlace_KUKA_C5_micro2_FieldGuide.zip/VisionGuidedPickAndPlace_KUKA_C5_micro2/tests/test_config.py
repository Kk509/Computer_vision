from vgpp.config import load_all, validate_config

def test_config_loads():
    c = load_all()
    assert c["robot"]["robot"]["model"] == "KR_6_R700_2_SEL"
    assert c["robot"]["robot"]["controller"] == "KR_C5_MICRO_2"

def test_physical_motion_is_locked_by_default():
    c = load_all()
    assert c["robot"]["motion"]["robot_motion_enabled"] is False
    assert c["system"]["robot_motion_enabled"] is False
