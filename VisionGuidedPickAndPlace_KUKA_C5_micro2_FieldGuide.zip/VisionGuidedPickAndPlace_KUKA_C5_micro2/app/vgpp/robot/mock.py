class MockRobot:
    def connect(self):
        return {"connected": True, "mode": "mock"}

    def send_validated_target(self, target):
        return {"accepted": True, "simulated": True, "target": target}

    def get_status(self):
        return {"state": "READY", "simulated": True}
