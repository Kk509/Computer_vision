import json
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from .config import load_all, CONFIG_DIR
from .camera.rc_visard import RcVisardClient
from .vision.boxpick import build_boxpick_args, parse_items, parse_grasps, filter_grasps

class CameraApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Vision-Guided Pick-and-Place — rc_visard")
        self.root.geometry("1050x720")
        self.config = load_all()
        self.last_result = None

        top = ttk.Frame(root, padding=10)
        top.pack(fill="x")
        ttk.Label(top, text="rc_visard address:").pack(side="left")
        self.url = tk.StringVar(value=self.config["camera"]["base_url"])
        ttk.Entry(top, textvariable=self.url, width=32).pack(side="left", padx=6)
        ttk.Button(top, text="Save address", command=self.save_address).pack(side="left")
        ttk.Button(top, text="Connect / status", command=self.check_camera).pack(side="left", padx=6)

        actions = ttk.LabelFrame(root, text="Camera operations", padding=10)
        actions.pack(fill="x", padx=10, pady=5)
        ttk.Button(actions, text="Detect boxes", command=self.detect).pack(side="left", padx=4)
        ttk.Button(actions, text="Calculate suction grasps", command=self.grasps).pack(side="left", padx=4)
        ttk.Button(actions, text="Open camera Web GUI", command=self.open_web).pack(side="left", padx=4)
        ttk.Button(actions, text="Save result JSON", command=self.save_result).pack(side="left", padx=4)

        self.status = tk.StringVar(value="Not connected")
        ttk.Label(root, textvariable=self.status, padding=(12,5)).pack(anchor="w")
        self.output = tk.Text(root, wrap="none", font=("Consolas", 10))
        self.output.pack(fill="both", expand=True, padx=10, pady=10)
        self.write("Ready. Connect the PC to the camera network, enter the camera IP, then select Connect / status.\\n")
        self.write("Robot motion is not available from this screen. Camera/BoxPick operations only.\\n")

    def client(self):
        return RcVisardClient(self.url.get().strip(),
                              self.config["camera"]["request_timeout_seconds"],
                              self.config["camera"]["verify_tls"])

    def write(self, text):
        self.output.insert("end", text + ("" if text.endswith("\\n") else "\\n"))
        self.output.see("end")

    def save_address(self):
        self.config["camera"]["base_url"] = self.url.get().strip().rstrip("/")
        path = CONFIG_DIR / "camera.json"
        path.write_text(json.dumps(self.config["camera"], indent=2), encoding="utf-8")
        self.status.set("Camera address saved to config/camera.json")
        self.write(f"Saved camera address: {self.url.get()}")

    def check_camera(self):
        try:
            report = self.client().health_report(self.config["boxpick"]["pipeline_id"])
            self.last_result = report
            self.status.set("Camera REST API reachable. Review module status below.")
            self.write(json.dumps(report, indent=2))
            bp = report.get("boxpick", {})
            self.write("Check that rc_boxpick is present/running and the BoxPick licence is active in the camera Web GUI.")
        except Exception as e:
            self.status.set("Connection failed")
            messagebox.showerror("Camera connection failed",
                f"{e}\\n\\nCheck PC Ethernet adapter IP/subnet, camera IP, cable/switch and firewall.")

    def detect(self):
        try:
            payload = self.client().boxpick_service("detect_items",
                build_boxpick_args(self.config, "detect_items"),
                self.config["boxpick"]["pipeline_id"])
            items = parse_items(payload)
            self.last_result = payload
            self.status.set(f"Detection complete: {len(items)} item(s)")
            self.write(json.dumps(payload, indent=2))
        except Exception as e:
            self.status.set("Detection failed")
            messagebox.showerror("BoxPick detection failed", str(e))

    def grasps(self):
        try:
            b = self.config["boxpick"]
            service = "compute_grasps_extended" if b.get("use_extended_service", True) else "compute_grasps"
            payload = self.client().boxpick_service(service, build_boxpick_args(self.config, service),
                                                      b["pipeline_id"])
            candidates = parse_grasps(payload)
            accepted = filter_grasps(candidates, b["minimum_grasp_quality"],
                                      b["minimum_ellipse_length_m"], b["minimum_ellipse_width_m"])
            result = {"service":service, "candidate_count":len(candidates),
                      "accepted_count":len(accepted),
                      "grasps":[{"item_uuid":g.item_uuid, "pose_frame":g.pose_frame,
                        "position_m":g.position_m, "quaternion_xyzw":g.quaternion_xyzw,
                        "quality":g.quality,
                        "max_suction_surface_m":[g.max_suction_surface_length_m,
                                                 g.max_suction_surface_width_m]}
                        for g in accepted],
                      "raw_response":payload}
            self.last_result = result
            self.status.set(f"Grasp calculation complete: {len(accepted)} accepted candidate(s)")
            self.write(json.dumps(result, indent=2))
        except Exception as e:
            self.status.set("Grasp calculation failed")
            messagebox.showerror("BoxPick grasp calculation failed", str(e))

    def open_web(self):
        import webbrowser
        webbrowser.open(self.url.get().strip())

    def save_result(self):
        if self.last_result is None:
            messagebox.showinfo("No result", "Run a camera check, detection or grasp calculation first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json",
                    filetypes=[("JSON files","*.json")], initialfile="rc_visard_result.json")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.last_result, f, indent=2)
            self.status.set(f"Saved: {path}")

def launch():
    root = tk.Tk()
    CameraApp(root)
    root.mainloop()
