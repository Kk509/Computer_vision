from dataclasses import dataclass
from typing import Any

@dataclass
class GraspCandidate:
    item_uuid: str | None
    position_m: tuple[float, float, float]
    quaternion_xyzw: tuple[float, float, float, float]
    quality: float
    max_suction_surface_length_m: float
    max_suction_surface_width_m: float
    pose_frame: str
    raw: dict

def _vec3(obj):
    return (float(obj["x"]), float(obj["y"]), float(obj["z"]))

def _quat(obj):
    # rc_visard response uses x/y/z/w members; internal representation is xyzw.
    return (float(obj["x"]), float(obj["y"]), float(obj["z"]), float(obj["w"]))

def response_body(payload: dict) -> dict:
    body = payload.get("response", payload)
    if not isinstance(body, dict):
        raise ValueError("Unexpected BoxPick response: 'response' is not an object.")
    rc = body.get("return_code", {})
    if isinstance(rc, dict) and int(rc.get("value", 0)) < 0:
        raise RuntimeError(f"BoxPick error {rc.get('value')}: {rc.get('message', '')}")
    return body

def parse_grasps(payload: dict) -> list[GraspCandidate]:
    body = response_body(payload)
    candidates = []
    for g in body.get("grasps", []):
        pose = g.get("pose")
        if not isinstance(pose, dict) or "position" not in pose or "orientation" not in pose:
            continue
        candidates.append(GraspCandidate(
            item_uuid=g.get("item_uuid", g.get("uuid")),
            position_m=_vec3(pose["position"]),
            quaternion_xyzw=_quat(pose["orientation"]),
            quality=float(g.get("quality", 0.0)),
            max_suction_surface_length_m=float(g.get("max_suction_surface_length", 0.0)),
            max_suction_surface_width_m=float(g.get("max_suction_surface_width", 0.0)),
            pose_frame=g.get("pose_frame", body.get("pose_frame", "camera")),
            raw=g
        ))
    return candidates

def parse_items(payload: dict) -> list[dict]:
    body = response_body(payload)
    return body.get("items", [])

def filter_grasps(candidates, min_quality: float, min_length: float, min_width: float):
    accepted = [
        g for g in candidates
        if g.quality >= min_quality
        and g.max_suction_surface_length_m >= min_length
        and g.max_suction_surface_width_m >= min_width
    ]
    return sorted(accepted, key=lambda g: g.quality, reverse=True)

def build_item_model(min_xy: list[float], max_xy: list[float]) -> dict:
    if len(min_xy) != 2 or len(max_xy) != 2:
        raise ValueError("BoxPick rectangle dimensions require [x, y] pairs in metres.")
    if min_xy[0] >= max_xy[0] or min_xy[1] >= max_xy[1]:
        raise ValueError("Each minimum box dimension must be smaller than its maximum.")
    return {
        "type": "RECTANGLE",
        "rectangle": {
            "min_dimensions": {"x": float(min_xy[0]), "y": float(min_xy[1])},
            "max_dimensions": {"x": float(max_xy[0]), "y": float(max_xy[1])}
        }
    }

def build_boxpick_args(config: dict, service: str) -> dict:
    b = config["boxpick"]
    args = {
        "pose_frame": b.get("pose_frame", "camera"),
        "item_models": [build_item_model(b["min_dimensions_m"], b["max_dimensions_m"])]
    }
    if service.startswith("compute_grasps"):
        args["suction_surface_length"] = float(b["suction_surface_length_m"])
        args["suction_surface_width"] = float(b["suction_surface_width_m"])
    if b.get("region_of_interest_id"):
        args["region_of_interest_id"] = b["region_of_interest_id"]
    if b.get("dimensioning_plane_id"):
        args["dimensioning"] = {"plane_ids": [b["dimensioning_plane_id"]]}
    if b.get("collision_gripper_id"):
        args["collision_detection"] = {"gripper_id": b["collision_gripper_id"]}
    return args
