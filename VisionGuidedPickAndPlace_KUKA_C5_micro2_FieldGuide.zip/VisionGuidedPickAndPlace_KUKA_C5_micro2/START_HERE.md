# START HERE — your first session with the rc_visard

This is the operating checklist. Follow it in order. Do not skip the checks.

## What you are doing

You are bringing up the vision part of the cell first. The PC talks to the fixed rc_visard over Ethernet.
The rc_visard runs stereo vision and BoxPick on the camera itself. Your PC sends BoxPick requests,
receives box/grasp poses, filters the results, and saves them. At this stage the KUKA is not commanded.

Official BoxPick docs: https://doc.rc-visard.com/latest/en/boxpick.html

## Before connecting anything

Ask the controls/IT engineer for:
- Camera IP address and subnet mask
- Whether the PC Ethernet port may be connected to the camera network
- Whether a switch is required
- Whether the rc_visard is powered and already configured
- Whether BoxPick is licensed and enabled

Do not guess an IP address or change a company network/controller address yourself.

## Session 1 — install the software on Windows

1. Copy the ZIP to your work PC.
2. Right-click it and choose **Extract All**.
3. Open the extracted `VisionGuidedPickAndPlace_KUKA_C5_micro2` folder.
4. Click the address bar in File Explorer, type `powershell`, press Enter.
5. Run these commands one at a time:

```powershell
py -3.11 --version
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[dev]"
pytest
```

If PowerShell blocks activation, use this for the current terminal only:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Expected test result: all tests pass. If dependency installation fails because the PC has no internet,
ask IT for the approved Python package installation route; do not download packages from unapproved sites.

## Session 2 — connect the PC to the camera

1. Connect the PC Ethernet cable to the approved camera network/switch.
2. Obtain the camera's IP address from the engineer or camera Web GUI/network record.
3. Enter that address in `config/camera.json`, for example:

```json
{
  "model": "rc_visard_160mmC",
  "mounting": "fixed",
  "base_url": "http://CAMERA_IP",
  "request_timeout_seconds": 8,
  "verify_tls": false
}
```

Replace `CAMERA_IP` with the actual address. Do not copy the example `192.168.0.10` unless that is confirmed to be the camera's address.

4. Open a browser and visit `http://CAMERA_IP/`.
5. Expected result: rc_visard Web GUI loads.
6. If it does not load, stop and check IP/subnet/cabling with the engineer. Do not continue to BoxPick.

## Session 3 — check the camera from the app

In the project PowerShell window, with `.venv` activated, run:

```powershell
vgpp camera-check
```

Expected result:
- REST API root response
- System information response (if supported by installed firmware)
- Pipeline node list
- rc_boxpick node information

If the `system` endpoint differs on the installed firmware, the Web GUI and API root are still the first checks; use the device's own Swagger/API page to confirm available endpoints.

Then launch the desktop app:

```powershell
vgpp desktop
```

In the app:
1. Confirm the camera address.
2. Click **Connect / status**.
3. Read the result area.
4. Confirm the BoxPick node exists and is running/available.
5. Check the camera Web GUI for the BoxPick licence and module status.

A camera REST connection does not prove that the BoxPick licence is installed. BoxPick is a separately licensed onboard module.

## Session 4 — configure BoxPick for your actual boxes

Before changing settings, measure a sample of the actual boxes.

Record:
- Short top-face dimension (metres)
- Long top-face dimension (metres)
- Manufacturing/measurement tolerance
- Whether box tops are flat, reflective, printed, damaged or partly occluded
- Whether boxes are touching/stacked

Open `config/boxpick.json`.

For `RECTANGLE`, set:
- `min_dimensions_m`: smallest expected top-face dimensions, in metres
- `max_dimensions_m`: largest expected top-face dimensions, in metres
- `suction_surface_length_m` and `suction_surface_width_m`: actual usable suction footprint, in metres
- `minimum_grasp_quality`: initial filter threshold to be tuned with real results
- `minimum_ellipse_length_m` and `minimum_ellipse_width_m`: minimum ellipse axes that the physical suction device needs

Do not use the example dimensions as real box dimensions.

Open the camera Web GUI → Modules → BoxPick:
1. Confirm the module is running.
2. Set up the scene and region of interest if required.
3. Start with the default `Unconstrained` detection mode unless the actual scene is a packed grid/layer case.
4. Review the intermediate line/cluster visualisation.
5. Tune using the actual scene and record the settings.

The app currently sends `RECTANGLE` item dimensions and suction footprint through the BoxPick API. It does not silently set all BoxPick runtime parameters; tune those in the Web GUI first.

## Session 5 — detect boxes

In the desktop app, click **Detect boxes**.

Expected:
- The output includes the raw service response and the detected `items` list.
- Each item should have a UUID, pose, pose frame and rectangle dimensions (or box dimensions if dimensioning is configured).
- The pose is in the camera frame when `pose_frame` is `camera`.

If zero items are returned:
1. Confirm BoxPick node is running/licensed.
2. Confirm correct min/max dimensions in metres.
3. Confirm boxes are visible and not outside the ROI.
4. Review BoxPick intermediate visualisation.
5. Check lighting, surface texture, depth quality and occlusions.
6. Read the service `return_code` and message.

## Session 6 — calculate suction grasps

Click **Calculate suction grasps**.

Expected:
- `candidate_count` / `grasps_returned`
- `accepted_count`
- For each accepted grasp: item UUID, pose frame, position, quaternion, quality and maximum suction ellipse dimensions.

BoxPick's grasp pose represents the recommended suction TCP pose. Its quality measures surface flatness; it does not guarantee an airtight physical seal. Verify suction on the real tool and box.

If no grasps are accepted:
1. Check raw response: did BoxPick return any candidates?
2. Compare the returned maximum suction ellipse dimensions with the actual cup/foam footprint.
3. Review minimum grasp quality threshold.
4. Inspect whether the top surface is flat and unobstructed.
5. Save the raw JSON and ask Roboception/controls engineer to review it.

## Session 7 — save evidence

Use **Save result JSON** in the desktop app after a successful detection and grasp calculation.
Keep:
- Camera IP and firmware (do not include credentials)
- BoxPick licence/module status
- Actual box dimensions and tolerances
- Gripper footprint
- Raw response JSON
- Screenshot of BoxPick Web GUI result
- Date/time and test notes

## What not to do yet

- Do not send any target to the physical KUKA from this camera-only app.
- Do not set `robot_motion_enabled` to true.
- Do not use the example identity calibration as a real transform.
- Do not use guessed tool/TCP/load data.
- Do not switch to `pose_frame: external` until the static camera hand-eye calibration is complete and verified.

## What happens after camera-only tests

The next stage is a robot-assisted static-camera hand-eye calibration. Roboception documents static-camera calibration as producing the camera pose in the selected external reference frame. The calibration fixture and robot movements must follow Roboception's procedure and the site's safety rules.

After calibration, the controls engineer must configure the KR C5 micro-2 / iiQKA.OS2 9.3 communication option and the controller-side program. Only then can camera grasps be converted into robot targets and physically tested.
