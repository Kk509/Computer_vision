# Camera-only quick start (no KUKA connection required)

## What you can do now

Once the PC can reach the rc_visard over Ethernet, the desktop application can:
- Query REST API and system/node information.
- Inspect the rc_boxpick node response.
- Call `detect_items`.
- Call `compute_grasps_extended`.
- Filter returned grasp candidates and show their pose/quality/suction footprint.
- Save raw or processed results as JSON.

It does not command robot motion.

## Connect

1. Ask the workplace network/controls engineer for the approved camera IP and subnet.
2. Connect PC Ethernet to the approved camera network.
3. Configure the PC adapter with an approved address in the same subnet. Do not guess/change
   production network settings.
4. Confirm reachability by opening `http://CAMERA_IP/` in a browser.
5. In `config/camera.json`, set `base_url` to `http://CAMERA_IP`.
6. Start the app with `vgpp desktop`.
7. Enter the same camera address and click **Connect / status**.

The camera REST API root is `/api/`; its Swagger UI exposes the installed firmware's API.

## BoxPick setup on camera

1. Open the rc_visard Web GUI from the desktop app.
2. Confirm BoxPick module is present and its separate licence is active.
3. On the BoxPick page, configure the scene and tune the detector.
4. Measure the boxes and set min/max X/Y top-surface dimensions in metres in
   `config/boxpick.json`.
5. Measure the effective suction footprint and set the surface length/width in metres.
6. Click **Detect boxes**.
7. Click **Calculate suction grasps**.
8. Save result JSON if needed.

If the camera reports an API error, inspect its return_code and compare the request schema with
the Swagger UI on that exact device firmware. API responses may differ between firmware releases.

## Correct BoxPick request shape

For `RECTANGLE`, `item_models` must contain a nested `rectangle` object:
- `rectangle.min_dimensions.x/y`
- `rectangle.max_dimensions.x/y`

The suction-grasp request additionally requires:
- `suction_surface_length`
- `suction_surface_width`

The application uses the API v2 endpoint:
`PUT /api/v2/pipelines/0/nodes/rc_boxpick/services/compute_grasps_extended`

## What camera-only mode cannot do

- It cannot produce robot-base coordinates until the camera-to-base transform is calibrated.
- It cannot check actual robot reachability without a commissioned robot model/controller interface.
- It cannot confirm a real suction seal.
- It cannot move the robot or switch vacuum I/O.

BoxPick grasp quality indicates reconstructed surface flatness; it is not a guarantee of a successful seal.
