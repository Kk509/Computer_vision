# Vision-Guided Box Pick-and-Place — KUKA KR 6 R700-2 + KR C5 micro-2

This repository is a configuration-driven integration project for:

- Roboception rc_visard 160mmC, fixed-mounted
- Roboception BoxPick (licence required)
- Suction gripper
- KUKA KR 6 R700-2 /SEL robot
- KUKA KR C5 micro-2 controller
- Target OS: iiQKA.OS2 9.3 (confirm exact installed build)
- External PC running the Python vision/orchestration application

## Important readiness statement

The repository includes a runnable development/mock pipeline, configuration validation,
camera REST client, BoxPick request client, grasp filtering, rigid-transform utilities,
tests, diagnostics, and integration documentation.

It is **not certified or proven on your physical cell**. Physical robot communication is
deliberately disabled until the exact iiQKA.EthernetKRL option/package version, controller
protocol configuration, robot-side KRL project, I/O mapping, and safety design are confirmed.
Do not enable robot motion by editing a JSON flag alone. A qualified engineer must complete
controller-side setup, safety validation, and low-speed commissioning.

## Hardware confirmed from supplied nameplate photos

- Robot: KUKA AGILUS-2, KR 6 R700-2 /SEL
- Controller: KUKA KR C5 micro-2
- Controller article number on label: 11124598
- Robot payload on label: 6 kg
- Robot reach on label: 726 mm
- Target OS supplied by project owner: iiQKA.OS2 9.3

The software configuration uses these values as defaults. Confirm the full OS build and
installed option packages from the controller before commissioning.

## First: follow the exact workplace procedure\n\nRead `START_HERE.md`. On Windows, run `WINDOWS_INSTALL.bat`, then `LAUNCH_CAMERA_APP.bat`.\n\n## Quick start (no hardware required)

1. Install Python 3.11 or 3.12.
2. Create a virtual environment.
3. Install dependencies.
4. Run tests.
5. Run the mock cycle.

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[dev]"
pytest
vgpp mock-cycle
```

### Linux

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e ".[dev]"
pytest
vgpp mock-cycle
```

## Configuration

All site-dependent values are in `config/`:

- `robot.json` — exact robot/controller target and communication mode
- `camera.json` — camera URL, timeout, expected model
- `boxpick.json` — BoxPick model and measured box-size limits
- `gripper.json` — measured suction footprint and TCP/tool data
- `calibration.json` — camera-to-robot-base transform
- `workspace.json` — engineer-defined permitted regions
- `system.json` — runtime and safety interlocks

Start with simulation mode. Example values are explicitly marked as placeholders.
Never use the example calibration or workspace values on a real robot.

## Commands

```bash
vgpp validate-config
vgpp mock-cycle
vgpp camera-check
vgpp boxpick-detect
vgpp boxpick-grasps
```

`camera-check`, `boxpick-detect`, and `boxpick-grasps` require a reachable camera and
an appropriately licensed/configured BoxPick module.

## High-level data flow

1. Query rc_visard health and BoxPick service availability.
2. Request BoxPick detection/grasp calculation.
3. Parse and filter grasp candidates.
4. Transform camera-frame poses into robot-base coordinates using the calibrated transform.
5. Validate the target against configured workspace limits.
6. Hand the target to a controller-specific adapter.
7. Controller-side KRL performs safety-checked approach, tool activation, pick, retract,
   transfer and release.

The Python application must not replace the robot controller's safety functions.

## Current physical integration boundary

`app/robot/iiqka_ethernetkrl.py` is an intentionally guarded adapter boundary. It refuses
to send motion commands until the actual EthernetKRL data contract is supplied and verified.
This is safer than inventing a socket protocol and claiming it works.

See `docs/INTEGRATION_GUIDE.md` and `docs/CONTROLLER_CHECKLIST.md`.
