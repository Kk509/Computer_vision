import requests

class RcVisardClient:
    def __init__(self, base_url: str, timeout: float = 8.0, verify_tls: bool = False):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.verify_tls = verify_tls
        self.session = requests.Session()

    def _request(self, method: str, path: str, **kwargs):
        response = self.session.request(method, f"{self.base_url}{path}",
                                        timeout=self.timeout, verify=self.verify_tls, **kwargs)
        response.raise_for_status()
        if not response.content:
            return {}
        try:
            return response.json()
        except ValueError:
            return {"raw_text": response.text}

    def get(self, path: str):
        return self._request("GET", path)

    def put(self, path: str, args: dict | None = None):
        return self._request("PUT", path, json={"args": args or {}})

    def api_root(self):
        return self.get("/api/")

    def system_info(self):
        return self.get("/api/v2/system")

    def nodes(self, pipeline_id: int = 0):
        return self.get(f"/api/v2/pipelines/{pipeline_id}/nodes")

    def node_info(self, node: str, pipeline_id: int = 0):
        return self.get(f"/api/v2/pipelines/{pipeline_id}/nodes/{node}")

    def boxpick_service(self, service: str, args: dict, pipeline_id: int = 0):
        return self.put(f"/api/v2/pipelines/{pipeline_id}/nodes/rc_boxpick/services/{service}", args)

    def health_report(self, pipeline_id: int = 0):
        return {
            "api": self.api_root(),
            "system": self.system_info(),
            "nodes": self.nodes(pipeline_id),
            "boxpick": self.node_info("rc_boxpick", pipeline_id)
        }
