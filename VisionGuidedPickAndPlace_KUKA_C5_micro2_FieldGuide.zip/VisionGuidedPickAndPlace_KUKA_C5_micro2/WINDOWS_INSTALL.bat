@echo off
setlocal
cd /d "%~dp0"
py -3.11 --version
if errorlevel 1 (
  echo Python 3.11 was not found. Install an approved Python 3.11 build or ask IT.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" py -3.11 -m venv .venv
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 goto fail
pip install -e ".[dev]"
if errorlevel 1 goto fail
pytest
if errorlevel 1 goto fail
echo.
echo Installation and tests completed.
echo Next run LAUNCH_CAMERA_APP.bat
pause
exit /b 0
:fail
echo.
echo Installation failed. Read the error above and follow START_HERE.md.
pause
exit /b 1
