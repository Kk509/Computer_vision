# Site configuration worksheet

| Setting | Where to obtain it | File |
|---|---|---|
| Camera IP/subnet | Controls/network engineer | camera.json |
| rc_visard firmware | Camera Web GUI | camera.json / notes |
| BoxPick licence | Camera Web GUI/licence page | boxpick.json |
| Box min/max dimensions | Measure representative boxes | boxpick.json |
| Suction footprint | Gripper datasheet/measurement | gripper.json + boxpick.json |
| TCP | Tool calibration | gripper.json |
| Tool load/CoG/inertia | Gripper CAD/datasheet and KUKA tool setup | gripper.json/controller |
| Camera-to-base transform | Calibration procedure | calibration.json |
| Pick/place bounds | Cell drawing and engineer approval | workspace.json |
| Controller IP | Controls engineer | robot.json |
| iiQKA.OS2 build | Controller system information | robot.json |
| EthernetKRL version | Installed option package list | robot.json |
| Communication contract | KUKA/controls engineer | controller/ |
| I/O mapping | Electrical drawings/controller I/O config | gripper.json/controller |

All example IP addresses and dimensions are placeholders. Do not use them without confirmation.
