# KR C5 micro-2 / iiQKA.OS2 9.3 controller checklist

Nameplate-confirmed:
- Controller: KR C5 micro-2
- Controller article number: 11124598
- Robot: KR 6 R700-2 /SEL
- Payload: 6 kg
- Reach: 726 mm

Confirm on the actual controller:
- [ ] Exact iiQKA.OS2 build/revision (not just major/minor marketing version)
- [ ] Installed iiQKA.EthernetKRL option and version/licence
- [ ] Supported external communication mode and configuration method
- [ ] Network IP/subnet/gateway and firewall policy
- [ ] Controller-side program deployment method and permissions
- [ ] Approved data schema and numeric units
- [ ] Quaternion/Euler convention and angle units
- [ ] Heartbeat, watchdog, timeout and stale-target rejection
- [ ] Robot state, mode, drives, faults and safety state feedback
- [ ] Vacuum output, vacuum OK input, blow-off output and electrical interface
- [ ] Tool data, payload, centre of gravity and inertia
- [ ] Base/tool calibration and coordinate conventions
- [ ] T1 commissioning plan, workspace and safety validation

Do not enable automatic mode until the responsible controls/safety engineer signs off.
