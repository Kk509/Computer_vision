import json
import typer
from rich import print
from .config import load_all, validate_config
from .camera.rc_visard import RcVisardClient
from .robot.mock import MockRobot
from .vision.boxpick import build_boxpick_args, parse_items, parse_grasps, filter_grasps

app = typer.Typer(help="Vision-guided pick-and-place diagnostics and mock runner.")

@app.command("validate-config")
def validate():
    errors = validate_config()
    if errors:
        print("[yellow]Configuration needs attention:[/yellow]")
        for e in errors: print(f" - {e}")
        raise typer.Exit(1)
    print("[green]Configuration checks passed.[/green]")

@app.command("mock-cycle")
def mock_cycle():
    robot = MockRobot()
    print(robot.connect())
    target = {"position_robot_base_m":[0.3,0.0,0.2],"quality":0.91}
    print(robot.send_validated_target(target))
    print("[green]Mock cycle complete. No physical robot was moved.[/green]")

@app.command("camera-check")
def camera_check():
    c = load_all()["camera"]
    client = RcVisardClient(c["base_url"], c["request_timeout_seconds"], c["verify_tls"])
    try:
        print(client.api_root())
        print(client.nodes())
        print("[green]Camera API reachable.[/green]")
    except Exception as e:
        print(f"[red]Camera check failed: {e}[/red]")
        raise typer.Exit(1)

@app.command("boxpick-detect")
def boxpick_detect():
    c = load_all()
    client = RcVisardClient(c["camera"]["base_url"], c["camera"]["request_timeout_seconds"],
                            c["camera"]["verify_tls"])
    try:
        payload = client.boxpick_service("detect_items",
                    build_boxpick_args(c, "detect_items"), c["boxpick"]["pipeline_id"])
        items = parse_items(payload)
        print(json.dumps({"count":len(items), "items":items,
                          "return_code":payload.get("response",payload).get("return_code")}, indent=2))
    except Exception as e:
        print(f"[red]BoxPick detection failed: {e}[/red]")
        raise typer.Exit(1)

@app.command("boxpick-grasps")
def boxpick_grasps():
    c = load_all()
    client = RcVisardClient(c["camera"]["base_url"], c["camera"]["request_timeout_seconds"],
                            c["camera"]["verify_tls"])
    b = c["boxpick"]
    service = "compute_grasps_extended" if b.get("use_extended_service", True) else "compute_grasps"
    try:
        payload = client.boxpick_service(service, build_boxpick_args(c, service), b["pipeline_id"])
        parsed = parse_grasps(payload)
        accepted = filter_grasps(parsed, b["minimum_grasp_quality"],
                                 b["minimum_ellipse_length_m"], b["minimum_ellipse_width_m"])
        output = [{
            "item_uuid":g.item_uuid, "pose_frame":g.pose_frame,
            "position_m":g.position_m, "quaternion_xyzw":g.quaternion_xyzw,
            "quality":g.quality,
            "max_suction_surface_m":[g.max_suction_surface_length_m,
                                     g.max_suction_surface_width_m]
        } for g in accepted]
        print(json.dumps({"grasps_returned":len(parsed), "grasps_accepted":len(output),
                          "grasps":output,
                          "return_code":payload.get("response",payload).get("return_code")}, indent=2))
    except Exception as e:
        print(f"[red]BoxPick grasp calculation failed: {e}[/red]")
        raise typer.Exit(1)

@app.command("desktop")
def desktop():
    """Launch the camera control desktop application."""
    from .desktop import launch
    launch()
