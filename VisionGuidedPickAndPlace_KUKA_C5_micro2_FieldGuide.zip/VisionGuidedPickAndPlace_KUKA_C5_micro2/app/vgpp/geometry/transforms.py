import numpy as np

def quaternion_xyzw_to_matrix(q):
    x, y, z, w = np.asarray(q, dtype=float)
    norm = np.linalg.norm([x, y, z, w])
    if norm == 0:
        raise ValueError("Quaternion must not be zero.")
    x, y, z, w = np.asarray([x, y, z, w], dtype=float) / norm
    return np.array([
        [1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
        [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
        [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]
    ], dtype=float)

def make_transform(translation_m, quaternion_xyzw):
    T = np.eye(4)
    T[:3,:3] = quaternion_xyzw_to_matrix(quaternion_xyzw)
    T[:3,3] = np.asarray(translation_m, dtype=float)
    return T

def transform_pose(T_target_source, position_source, quaternion_source_xyzw):
    p = np.asarray([*position_source, 1.0], dtype=float)
    p_target = T_target_source @ p
    R_target_source = T_target_source[:3,:3]
    R_source_pose = quaternion_xyzw_to_matrix(quaternion_source_xyzw)
    R_target_pose = R_target_source @ R_source_pose
    # Return matrix rotation; controller adapter must convert using verified convention.
    return p_target[:3], R_target_pose
