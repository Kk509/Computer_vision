# Integration guide

## A. Before visiting the cell

1. Install Python 3.11+ and the project in a virtual environment.
2. Run `pytest` and `vgpp mock-cycle`.
3. Print/export the configuration files and the controller checklist.
4. Obtain the exact rc_visard firmware version and BoxPick licence status.
5. Obtain the installed iiQKA.OS2 build and installed option-package list.
6. Obtain suction-gripper datasheet, TCP drawing, vacuum generator/valve I/O data.
7. Obtain box size range and collection-box placement requirements.

## B. Camera network and API

1. Ask the controls engineer for the camera IP, subnet, gateway and PC network plan.
2. Connect the PC and rc_visard to the approved network; do not change a company network
   or controller IP without authorisation.
3. Set `config/camera.json` `base_url`.
4. Open the camera Web GUI and verify the camera is healthy.
5. Run `vgpp camera-check`.
6. Verify BoxPick licence and service availability in the camera UI/API.
7. Configure the BoxPick RECTANGLE item model using measured min/max dimensions in metres.
8. Configure ROI and load carrier as required by the actual scene.
9. Run `vgpp boxpick-detect`, inspect returned items, then `vgpp boxpick-grasps`.
10. Validate API response fields against the installed firmware's API documentation before
    enabling downstream automation.

## C. Fixed-camera calibration

1. Establish a repeatable calibration target and the robot-base coordinate frame.
2. Use the approved Roboception hand-eye/static-camera calibration procedure for the installed
   firmware and the site's calibration fixture.
3. Record the transform from camera frame to robot base in `config/calibration.json`.
4. Confirm translation units are metres and quaternion ordering is x,y,z,w.
5. Independently verify several known points throughout the working volume.
6. Set `confirmed=true` only after engineer review. The example identity transform is not real.

## D. Suction tool

1. Obtain gripper CAD/datasheet and vacuum system details.
2. Measure/calibrate the TCP at the suction contact point.
3. Measure effective suction footprint; configure BoxPick suction dimensions.
4. Configure tool load, centre of gravity and inertia in the robot tool data using KUKA's
   approved commissioning process.
5. Configure vacuum output, vacuum OK input and blow-off output using the actual I/O map.
6. Verify a physical seal on representative boxes without robot automatic motion.

## E. Controller interface

1. Confirm controller is KR C5 micro-2 and robot KR 6 R700-2 /SEL from nameplates.
2. Confirm exact iiQKA.OS2 9.3 build and whether iiQKA.EthernetKRL is installed/licensed.
3. Obtain the supported version-specific EthernetKRL manual and sample project from KUKA.
4. Controls engineer defines approved connection mode, endpoint/port, data framing, request/response
   schema, heartbeat, timeouts, state feedback, fault response and safe stop behaviour.
5. Implement and bench-test the matching adapter and KRL side program.
6. Do not assume legacy KSS/EKI XML or EKIBridge KSS sample code is drop-in compatible.
7. Verify controller I/O mapping and tool signals.
8. Test status-only exchange first; then target exchange with motion inhibited.

## F. Commissioning sequence

1. Simulation-only; robot motion disabled.
2. Camera detection only.
3. Grasp pose visualisation and manual coordinate verification.
4. Robot target exchange with drives disabled / no motion.
5. Engineer-approved T1 low-speed approach tests with safe clearances.
6. Verify vacuum, object-present feedback, release and recovery behaviour.
7. Test missing object, poor grasp, camera timeout, network loss, vacuum failure and emergency stop.
8. Complete risk assessment, safeguarding, safety validation and sign-off before automatic operation.

## G. Repeated cycle logic

The final controller-side program should implement a state machine:
IDLE -> REQUEST_TARGET -> VALIDATE -> APPROACH -> DESCEND -> VACUUM_ON ->
VERIFY_VACUUM -> LIFT -> MOVE_TO_PLACE -> RELEASE -> VERIFY_RELEASE -> IDLE.
On any fault: stop normal cycle, report fault, move only according to the approved recovery
procedure, and require operator intervention where specified.
