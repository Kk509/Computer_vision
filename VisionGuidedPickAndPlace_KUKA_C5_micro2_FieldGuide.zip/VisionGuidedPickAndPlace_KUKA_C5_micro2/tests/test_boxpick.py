from vgpp.vision.boxpick import parse_grasps, filter_grasps, build_item_model, build_boxpick_args

def test_parse_documented_grasp_response():
    payload = {"response":{"grasps":[
      {"item_uuid":"abc","pose":{"position":{"x":0.1,"y":0.2,"z":0.3},
       "orientation":{"x":0,"y":0,"z":0,"w":1}},
       "quality":0.9,"max_suction_surface_length":0.07,
       "max_suction_surface_width":0.06,"pose_frame":"camera"}
    ],"return_code":{"value":0,"message":"Success"}}}
    parsed = parse_grasps(payload)
    assert len(parsed) == 1
    assert parsed[0].item_uuid == "abc"
    assert parsed[0].max_suction_surface_width_m == 0.06
    accepted = filter_grasps(parsed, 0.5, 0.04, 0.04)
    assert len(accepted) == 1

def test_boxpick_rectangle_request_schema():
    model = build_item_model([0.1,0.1],[0.4,0.3])
    assert model["type"] == "RECTANGLE"
    assert model["rectangle"]["min_dimensions"]["x"] == 0.1
    assert model["rectangle"]["max_dimensions"]["y"] == 0.3

def test_boxpick_grasp_args():
    c = {"boxpick":{"pose_frame":"camera","min_dimensions_m":[0.1,0.1],
         "max_dimensions_m":[0.3,0.3],"suction_surface_length_m":0.08,
         "suction_surface_width_m":0.07}}
    args = build_boxpick_args(c,"compute_grasps_extended")
    assert args["item_models"][0]["rectangle"]["min_dimensions"]["x"] == 0.1
    assert args["suction_surface_length"] == 0.08
